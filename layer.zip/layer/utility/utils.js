function underscore(camelCasedWord) {
  if (!camelCasedWord.match(/[A-Z-]|::/g)) return camelCasedWord;
  let word = camelCasedWord.toString().replace(/::/g, ".");
  word = word.replace(/([A-Z\d]+)([A-Z][a-z])/g, "$1_$2");
  word = word.replace(/([a-z\d])([A-Z])/g, "$1_$2");
  word = word.replace(/-/g, "_");
  word = word.toLowerCase();
  return word;
}

function normalizeKeys(record) {
  const updatedRecord = [];
  for (const key of Object.keys(record)) {
    updatedRecord[underscore(key)] = record[key];
  }
  return updatedRecord;
}

function addNewField(record, newFields) {
  return { ...record, ...newFields };
}

function removeField(record, fields) {
  fields.forEach(field => {
    delete record[field]
  })
  return record
}

const garminDailiesAllowedParams = [
  "steps",
  "active_time_in_seconds",
  "moderate_intensity_duration_in_seconds",
  "vigorous_intensity_duration_in_seconds",
  "floors_climbed",
  "active_kilocalories",
];

module.exports = { garminDailiesAllowedParams, normalizeKeys, underscore, addNewField, removeField };
