const AWS = require("aws-sdk");

var clientSecret = new AWS.SecretsManager({
  region: process.env.AWS_REGION,
  endpoint: process.env.endpoint,
});

exports.retrieveSecret = async function(secretName) {
  let secret = "";
  await clientSecret
    .getSecretValue({ SecretId: secretName }, function (err, data) {
      if (err) {
        if (err.code === "DecryptionFailureException") throw err;
        else if (err.code === "InternalServiceErrorException") throw err;
        else if (err.code === "InvalidParameterException") throw err;
        else if (err.code === "InvalidRequestException") throw err;
        else if (err.code === "ResourceNotFoundException") throw err;
      } else {
        if ("SecretString" in data) {
          secret = data.SecretString;
        } else {
          let buff = new Buffer(data.SecretBinary, "base64");
          secret = buff.toString("ascii");
        }
      }
    })
    .promise();
  return secret;
}